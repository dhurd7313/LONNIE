import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.lonnie.agent",
  appName: "LONNIE",
  webDir: "dist",
  server: {
    // Allow cleartext (http) for local Ollama when on same network
    cleartext: true,
    androidScheme: "https",
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1000,
      backgroundColor: "#0a0c10",
      showSpinner: false,
    },
  },
};

export default config;
